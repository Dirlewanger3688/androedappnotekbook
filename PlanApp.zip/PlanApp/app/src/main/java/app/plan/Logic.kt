package app.plan

import android.content.Context
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Logic {
    fun today() = LocalDate.now().toEpochDay()
    fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    fun parseTime(s: String): Int = runCatching { val p = s.trim().split(":", "."); p[0].toInt() * 60 + p[1].toInt() }.getOrDefault(540)

    fun block(t: Task) = when {
        t.minutes < 0 -> "Без часу"; t.minutes < 720 -> "Ранок"; t.minutes < 1020 -> "День"; else -> "Вечір"
    }

    fun color(c: String) = when (c) {
        "Навчання" -> Color(0xFF7FA6D9); "Здоров'я" -> Color(0xFF7FC99A); "Проєкти" -> Color(0xFFD9B27F); else -> Color(0xFFB0B0B0)
    }

    fun overdue(t: Task, td: Long) = if (t.kind == "PERIOD") t.periodEnd in 1 until td else t.dueDay < td

    fun visible(t: Task, all: List<Task>, td: Long): Boolean {
        if (t.status != "PENDING" || t.dueDay > td || t.lastDone == td) return false
        if (t.dependsOn == 0L) return true
        val d = all.firstOrNull { it.id == t.dependsOn } ?: return true
        return d.lastDone == td || d.status == "DONE"
    }

    fun next(t: Task, from: Long): Long = when (t.repeat) {
        "DAILY" -> from + 1
        "INTERVAL" -> from + maxOf(1, t.repeatArg)
        "DAYS" -> (1..7).map { from + it }.firstOrNull { ((t.repeatArg shr (LocalDate.ofEpochDay(it).dayOfWeek.value - 1)) and 1) == 1 } ?: (from + 1)
        else -> from
    }

    fun lightestDay(all: List<Task>, td: Long): Long =
        (1L..7L).minByOrNull { o -> all.count { it.status == "PENDING" && it.dueDay == td + o } }!! + td

    suspend fun create(c: Context, t: Task) {
        val dao = Db.get(c).dao()
        val id = dao.add(t)
        dao.log(Log(taskId = id, text = "Створено · ${t.title}"))
        Notify.schedule(c, t.copy(id = id))
    }

    suspend fun move(c: Context, t: Task, day: Long) {
        val dao = Db.get(c).dao()
        val n = t.copy(dueDay = day, periodEnd = if (t.kind == "PERIOD") maxOf(t.periodEnd, day) else 0)
        dao.update(n); dao.log(Log(taskId = t.id, text = "Перенесено · ${t.title}"))
        Notify.schedule(c, n)
    }

    suspend fun checkIn(c: Context, id: Long, action: String) {
        val dao = Db.get(c).dao()
        val t = dao.get(id) ?: return
        val td = today(); val rep = t.repeat != "NONE"
        val n = when (action) {
            "DONE" -> {
                val st = if (t.lastDone == td - 1) t.streak + 1 else if (t.lastDone == td) t.streak else 1
                val dn = t.done + 1
                if (rep) t.copy(done = 0, streak = st, lastDone = td, dueDay = next(t, td))
                else t.copy(done = dn, streak = st, lastDone = td, status = if (dn >= t.target) "DONE" else "PENDING")
            }
            "SKIP" -> if (rep) t.copy(streak = 0, dueDay = next(t, td), lastDone = td) else t.copy(status = "SKIPPED", streak = 0)
            else -> t.copy(dueDay = td + 1)
        }
        dao.update(n)
        dao.log(Log(taskId = id, text = (when (action) { "DONE" -> "Виконано"; "SKIP" -> "Пропущено"; else -> "Відкладено" }) + " · ${t.title}"))
        Notify.cancel(c, id)
        if (n.status == "PENDING") Notify.schedule(c, n)
        if (action == "DONE") dao.list().filter { it.dependsOn == id && it.status == "PENDING" && it.kind != "EXACT" }
            .forEach { Notify.at(c, it.id, System.currentTimeMillis() + 1000) }
    }

    // Дуже проста розмова: "додай купити хліб завтра о 18:30", "щодня зарядка о 7"
    suspend fun voiceAdd(c: Context, s: String) {
        val m = Regex("(?:\\bо|\\bна|\\bв)\\s*(\\d{1,2})(?:[:. ](\\d{2}))?\\b").find(s)
        var title = s.replace(Regex("^(додай|створи|нагадай)\\s*", RegexOption.IGNORE_CASE), "")
        m?.let { title = title.replace(it.value, "") }
        title = title.replace("завтра", "").replace("щодня", "").replace(Regex("\\s+"), " ").trim()
        if (title.isEmpty()) return
        val min = m?.let { it.groupValues[1].toInt() * 60 + (it.groupValues[2].toIntOrNull() ?: 0) } ?: -1
        val td = today() + if (s.contains("завтра")) 1 else 0
        create(c, Task(title = title.replaceFirstChar { it.uppercase() }, kind = if (min >= 0) "EXACT" else "DAY", minutes = min,
            dueDay = td, repeat = if (s.contains("щодня")) "DAILY" else "NONE"))
    }

    fun toJson(l: List<Task>): String = JSONArray(l.map { t ->
        JSONObject().put("id", t.id).put("title", t.title).put("category", t.category).put("kind", t.kind)
            .put("minutes", t.minutes).put("duration", t.duration).put("dueDay", t.dueDay).put("periodEnd", t.periodEnd)
            .put("target", t.target).put("done", t.done).put("repeat", t.repeat).put("repeatArg", t.repeatArg)
            .put("dependsOn", t.dependsOn).put("streak", t.streak).put("status", t.status)
    }).toString(2)
}
