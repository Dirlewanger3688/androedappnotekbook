package app.plan

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color.Black, surface = Color.Black, primary = Color.White, onPrimary = Color.Black,
                onBackground = Color.White, onSurface = Color.White, surfaceVariant = Color(0xFF1A1A1A))) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val c = LocalContext.current; val sc = rememberCoroutineScope()
    val dao = remember { Db.get(c).dao() }
    val tasks by dao.tasks().collectAsState(emptyList())
    val logs by dao.logs().collectAsState(emptyList())
    var tab by remember { mutableIntStateOf(0) }; var add by remember { mutableStateOf(false) }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { sc.launch { Logic.voiceAdd(c, it) } }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) sc.launch(Dispatchers.IO) { c.contentResolver.openOutputStream(u)?.use { it.write(Logic.toJson(tasks).toByteArray()) } }
    }
    Scaffold(containerColor = Color.Black,
        topBar = {
            TopAppBar(title = { Text("План") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White),
                actions = {
                    TextButton({ voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")) }) { Text("Голос") }
                    TextButton({ export.launch("plan.json") }) { Text("Експорт") }
                })
        },
        floatingActionButton = { FloatingActionButton({ add = true }, containerColor = Color.White, contentColor = Color.Black) { Text("+", fontSize = 24.sp) } }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab, containerColor = Color.Black) {
                Tab(tab == 0, { tab = 0 }) { Text("Сьогодні", Modifier.padding(12.dp)) }
                Tab(tab == 1, { tab = 1 }) { Text("Журнал", Modifier.padding(12.dp)) }
            }
            if (tab == 0) Today(tasks) else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(logs) { l ->
                    Text("${SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(l.ts))}  ${l.text}", color = Color.LightGray, fontSize = 13.sp)
                }
            }
        }
    }
    if (add) AddDialog(tasks) { add = false }
}

@Composable
fun Today(all: List<Task>) {
    val c = LocalContext.current; val sc = rememberCoroutineScope(); val td = Logic.today()
    val vis = all.filter { Logic.visible(it, all, td) }
    val over = vis.filter { Logic.overdue(it, td) }
    val rest = vis - over.toSet()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (over.isNotEmpty()) {
            item { Text("Прострочено", color = Color.Gray) }
            item {
                Row {
                    TextButton({ sc.launch { over.forEach { Logic.move(c, it, td + 1) } } }) { Text("Усі на завтра") }
                    TextButton({ sc.launch { val d = Logic.lightestDay(all, td); over.forEach { Logic.move(c, it, d) } } }) { Text("На вільний день") }
                }
            }
            items(over) { t -> TaskRow(t) }
        }
        listOf("Ранок", "День", "Вечір", "Без часу").forEach { b ->
            val l = rest.filter { Logic.block(it) == b }.sortedBy { it.minutes }
            if (l.isNotEmpty()) { item { Text(b, color = Color.Gray) }; items(l) { t -> TaskRow(t) } }
        }
        if (vis.isEmpty()) item { Text("На сьогодні нічого немає", color = Color.Gray) }
    }
}

@Composable
fun TaskRow(t: Task) {
    val c = LocalContext.current; val sc = rememberCoroutineScope()
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(Logic.color(t.category), CircleShape)); Spacer(Modifier.width(8.dp))
                Column {
                    Text(t.title, color = Color.White)
                    Text(buildString {
                        if (t.minutes >= 0) append(Logic.hm(t.minutes) + " · ")
                        if (t.duration > 0) append("${t.duration} хв · ")
                        append(t.category); if (t.streak > 1) append(" · серія ${t.streak}")
                    }, color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (t.target > 1) {
                LinearProgressIndicator(progress = { t.done.toFloat() / t.target }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = Color.White, trackColor = Color(0xFF333333))
                Text("${t.done}/${t.target}", color = Color.Gray, fontSize = 12.sp)
            }
            Row {
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "DONE") } }) { Text("Виконано") }
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "SKIP") } }) { Text("Пропущено") }
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "POSTPONE") } }) { Text("Відкласти") }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) =
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        opts.forEach { (v, l) -> FilterChip(sel == v, { on(v) }, { Text(l, fontSize = 12.sp) }) }
    }

@Composable
fun AddDialog(all: List<Task>, close: () -> Unit) {
    val c = LocalContext.current; val sc = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("Побут") }
    var kind by remember { mutableStateOf("DAY") }; var time by remember { mutableStateOf("14:30") }
    var target by remember { mutableStateOf("3") }; var days by remember { mutableStateOf("7") }
    var rep by remember { mutableStateOf("NONE") }; var arg by remember { mutableStateOf("2") }; var mask by remember { mutableIntStateOf(0) }
    var dur by remember { mutableStateOf("0") }; var pers by remember { mutableStateOf(false) }; var dep by remember { mutableStateOf("0") }
    AlertDialog(onDismissRequest = close,
        confirmButton = {
            TextButton({
                if (title.isNotBlank()) {
                    val td = Logic.today()
                    val t = Task(title = title.trim(), category = cat, kind = kind,
                        minutes = if (kind == "EXACT") Logic.parseTime(time) else -1, duration = dur.toIntOrNull() ?: 0,
                        dueDay = td, periodEnd = if (kind == "PERIOD") td + (days.toLongOrNull() ?: 7) else 0,
                        target = if (kind == "PERIOD") (target.toIntOrNull() ?: 1) else 1, repeat = rep,
                        repeatArg = if (rep == "DAYS") mask else (arg.toIntOrNull() ?: 1), dependsOn = dep.toLong(), persistent = pers)
                    sc.launch { Logic.create(c, t) }; close()
                }
            }) { Text("Додати") }
        },
        dismissButton = { TextButton(close) { Text("Скасувати") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Назва") })
                Chips(listOf("Побут", "Навчання", "Здоров'я", "Проєкти").map { it to it }, cat) { cat = it }
                Chips(listOf("EXACT" to "Точний час", "DAY" to "Протягом дня", "PERIOD" to "Протягом періоду"), kind) { kind = it }
                if (kind == "EXACT") OutlinedTextField(time, { time = it }, label = { Text("Час ГГ:ХХ") })
                if (kind == "PERIOD") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(target, { target = it }, label = { Text("Разів") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(days, { days = it }, label = { Text("Днів") }, modifier = Modifier.weight(1f))
                }
                Text("Повторення", color = Color.Gray, fontSize = 12.sp)
                Chips(listOf("NONE" to "Немає", "DAILY" to "Щодня", "DAYS" to "Дні тижня", "INTERVAL" to "Кожні N днів"), rep) { rep = it }
                if (rep == "INTERVAL") OutlinedTextField(arg, { arg = it }, label = { Text("N днів") })
                if (rep == "DAYS") Chips(listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд").mapIndexed { i, s -> i.toString() to s },
                    "") { mask = mask xor (1 shl it.toInt()) }
                OutlinedTextField(dur, { dur = it }, label = { Text("Тривалість, хв") })
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(pers, { pers = it }); Spacer(Modifier.width(8.dp)); Text("Наполегливе нагадування") }
                val pend = all.filter { it.status == "PENDING" }.take(6)
                if (pend.isNotEmpty()) {
                    Text("Після завершення завдання", color = Color.Gray, fontSize = 12.sp)
                    Chips(listOf("0" to "Незалежне") + pend.map { it.id.toString() to it.title }, dep) { dep = it }
                }
            }
        })
}
