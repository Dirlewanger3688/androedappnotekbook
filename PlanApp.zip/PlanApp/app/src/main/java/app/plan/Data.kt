package app.plan

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "Побут",
    val kind: String = "DAY",          // EXACT | DAY | PERIOD
    val minutes: Int = -1,             // час доби в хвилинах, -1 = без часу
    val duration: Int = 0,             // тривалість, хв
    val dueDay: Long,                  // epochDay
    val periodEnd: Long = 0,           // кінець періоду (для PERIOD)
    val target: Int = 1,               // скільки разів виконати
    val done: Int = 0,
    val repeat: String = "NONE",       // NONE | DAILY | DAYS | INTERVAL
    val repeatArg: Int = 0,            // N днів або бітова маска Пн..Нд
    val dependsOn: Long = 0,           // id завдання-попередника
    val streak: Int = 0,
    val lastDone: Long = -1,
    val status: String = "PENDING",    // PENDING | DONE | SKIPPED
    val persistent: Boolean = false    // наполегливе нагадування
)

@Entity
data class Log(@PrimaryKey(autoGenerate = true) val id: Long = 0, val taskId: Long, val text: String, val ts: Long = System.currentTimeMillis())

@Dao
interface Dao {
    @Query("SELECT * FROM Task") fun tasks(): Flow<List<Task>>
    @Query("SELECT * FROM Task") suspend fun list(): List<Task>
    @Query("SELECT * FROM Task WHERE id=:id") suspend fun get(id: Long): Task?
    @Insert suspend fun add(t: Task): Long
    @Update suspend fun update(t: Task)
    @Insert suspend fun log(l: Log)
    @Query("SELECT * FROM Log ORDER BY ts DESC LIMIT 200") fun logs(): Flow<List<Log>>
}

@Database(entities = [Task::class, Log::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): Dao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context): Db = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "plan.db").build().also { i = it }
        }
    }
}
