package app.plan

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter

// Кнопки "Змінити" / "Видалити" (з підтвердженням)
@Composable
fun TaskActions(t: Task, onEdit: (Task) -> Unit) {
    val c = LocalContext.current; var ask by remember { mutableStateOf(false) }
    Row {
        TextButton({ onEdit(t) }) { Text("Змінити") }
        TextButton({ ask = true }) { Text("Видалити") }
    }
    if (ask) AlertDialog({ ask = false }, title = { Text("Видалити «${t.title}»?") },
        confirmButton = { TextButton({ Logic.scope.launch { Logic.delete(c, t) }; ask = false }) { Text("Видалити") } },
        dismissButton = { TextButton({ ask = false }) { Text("Скасувати") } })
}

// Вкладка "Усі": усі завдання, включно з виконаними та майбутніми
@Composable
fun AllTasks(all: List<Task>, onEdit: (Task) -> Unit) {
    val l = all.sortedWith(compareBy({ it.status != "PENDING" }, { it.dueDay }))
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (l.isEmpty()) item { Text("Завдань немає", color = Color.Gray) }
        items(l) { t ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(Logic.color(t.category), CircleShape)); Spacer(Modifier.width(8.dp))
                        Text(t.title, color = if (t.status == "PENDING") Color.White else Color.Gray)
                    }
                    Text(buildString {
                        append(LocalDate.ofEpochDay(t.dueDay).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")))
                        if (t.minutes >= 0) append(" · " + Logic.hm(t.minutes))
                        append(" · " + t.category)
                        if (t.repeat != "NONE") append(" · повторюється")
                        if (t.important) append(" · важливе"); if (t.urgent) append(" · термінове")
                        if (t.status == "DONE") append(" · виконано"); if (t.status == "SKIPPED") append(" · пропущено")
                    }, color = Color.Gray, fontSize = 12.sp)
                    TaskActions(t, onEdit)
                }
            }
        }
    }
}

// Створення / редагування. init: null = нове, Task з id = редагування, Task з id=0 = чернетка з голосу
@Composable
fun AddDialog(all: List<Task>, cats: List<String>, init: Task?, heard: String, close: () -> Unit) {
    val c = LocalContext.current
    val d = remember { init ?: Task(title = "", dueDay = Logic.today()) }
    val editing = d.id != 0L
    var title by remember { mutableStateOf(d.title) }; var cat by remember { mutableStateOf(d.category) }; var custom by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(d.kind) }
    var time by remember { mutableStateOf(if (d.minutes >= 0) Logic.hm(d.minutes) else "14:30") }
    var target by remember { mutableStateOf(if (d.kind == "PERIOD") d.target.toString() else "3") }
    var days by remember { mutableStateOf(if (d.kind == "PERIOD") maxOf(1L, d.periodEnd - d.dueDay).toString() else "7") }
    var rep by remember { mutableStateOf(d.repeat) }
    var arg by remember { mutableStateOf(if (d.repeat == "INTERVAL") d.repeatArg.toString() else "2") }
    var mask by remember { mutableIntStateOf(if (d.repeat == "DAYS") d.repeatArg else 0) }
    var dur by remember { mutableStateOf(d.duration.toString()) }; var pers by remember { mutableStateOf(d.persistent) }
    var imp by remember { mutableStateOf(d.important) }; var urg by remember { mutableStateOf(d.urgent) }
    var dep by remember { mutableStateOf(d.dependsOn.toString()) }; var due by remember { mutableLongStateOf(d.dueDay) }
    var ask by remember { mutableStateOf(false) }
    val tags = remember { (cats + d.category).distinct() }
    AlertDialog(onDismissRequest = close,
        confirmButton = {
            TextButton({
                if (title.isNotBlank()) {
                    val t = d.copy(title = title.trim(), category = custom.trim().ifEmpty { cat }, kind = kind,
                        minutes = if (kind == "EXACT") Logic.parseTime(time) else -1, duration = dur.toIntOrNull() ?: 0, dueDay = due,
                        periodEnd = if (kind == "PERIOD") due + (days.toLongOrNull() ?: 7) else 0,
                        target = if (kind == "PERIOD") (target.toIntOrNull() ?: 1) else 1, repeat = rep,
                        repeatArg = if (rep == "DAYS") mask else (arg.toIntOrNull() ?: 1), dependsOn = dep.toLong(),
                        persistent = pers, important = imp, urgent = urg)
                    Logic.scope.launch { if (editing) Logic.update(c, t) else Logic.create(c, t) }
                    close()
                }
            }) { Text(if (editing) "Зберегти" else "Додати") }
        },
        dismissButton = {
            Row {
                if (editing) TextButton({ ask = true }) { Text("Видалити") }
                TextButton(close) { Text("Скасувати") }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (heard.isNotEmpty()) Text("Розпізнано: «$heard». Перевірте поля й натисніть «Додати».", color = Color.Gray, fontSize = 12.sp)
                OutlinedTextField(title, { title = it }, label = { Text("Назва") })
                Chips(tags.map { it to it }, cat) { cat = it; custom = "" }
                OutlinedTextField(custom, { custom = it }, label = { Text("Або свій тег") })
                TextButton({
                    val ld = LocalDate.ofEpochDay(due)
                    DatePickerDialog(c, { _, y, m, dd -> due = LocalDate.of(y, m + 1, dd).toEpochDay() }, ld.year, ld.monthValue - 1, ld.dayOfMonth).show()
                }) { Text("Дата: " + LocalDate.ofEpochDay(due).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))) }
                Chips(listOf("EXACT" to "Точний час", "DAY" to "Протягом дня", "PERIOD" to "Протягом періоду"), kind) { kind = it }
                if (kind == "EXACT") OutlinedTextField(time, { time = it }, label = { Text("Час ГГ:ХХ") })
                if (kind == "PERIOD") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(target, { target = it }, label = { Text("Разів") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(days, { days = it }, label = { Text("Днів") }, modifier = Modifier.weight(1f))
                }
                Text("Повторення", color = Color.Gray, fontSize = 12.sp)
                Chips(listOf("NONE" to "Немає", "DAILY" to "Щодня", "DAYS" to "Дні тижня", "INTERVAL" to "Кожні N днів"), rep) { rep = it }
                if (rep == "INTERVAL") OutlinedTextField(arg, { arg = it }, label = { Text("N днів") })
                if (rep == "DAYS") Chips(listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд").mapIndexed { i, s -> i.toString() to (if ((mask shr i) and 1 == 1) "✓ $s" else s) },
                    "") { mask = mask xor (1 shl it.toInt()) }
                OutlinedTextField(dur, { dur = it }, label = { Text("Тривалість, хв") })
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(pers, { pers = it }); Spacer(Modifier.width(8.dp)); Text("Наполегливе нагадування") }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(imp, { imp = it }); Spacer(Modifier.width(8.dp)); Text("Важливе") }
                Row(verticalAlignment = Alignment.CenterVertically) { Switch(urg, { urg = it }); Spacer(Modifier.width(8.dp)); Text("Термінове") }
                val pend = all.filter { it.status == "PENDING" && it.id != d.id }.take(6)
                if (pend.isNotEmpty()) {
                    Text("Після завершення завдання", color = Color.Gray, fontSize = 12.sp)
                    Chips(listOf("0" to "Незалежне") + pend.map { it.id.toString() to it.title }, dep) { dep = it }
                }
            }
        })
    if (ask) AlertDialog({ ask = false }, title = { Text("Видалити «${d.title}»?") },
        confirmButton = { TextButton({ Logic.scope.launch { Logic.delete(c, d) }; ask = false; close() }) { Text("Видалити") } },
        dismissButton = { TextButton({ ask = false }) { Text("Скасувати") } })
}
