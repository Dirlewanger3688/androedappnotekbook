package app.plan

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity
data class Task(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String = "Побут",
    val kind: String = "DAY",          // EXACT | DAY | PERIOD
    val minutes: Int = -1,             // час доби в хвилинах, -1 = без часу
    val duration: Int = 0,             // тривалість, хв
    val dueDay: Long,                  // epochDay
    val periodEnd: Long = 0,           // кінець періоду (для PERIOD)
    val target: Int = 1,               // скільки разів виконати
    val done: Int = 0,
    val repeat: String = "NONE",       // NONE | DAILY | DAYS | INTERVAL
    val repeatArg: Int = 0,            // N днів або бітова маска Пн..Нд
    val dependsOn: Long = 0,           // id завдання-попередника
    val streak: Int = 0,
    val lastDone: Long = -1,
    val status: String = "PENDING",    // PENDING | DONE | SKIPPED
    val persistent: Boolean = false,   // наполегливе нагадування
    val important: Boolean = false,    // матриця Ейзенхауера
    val urgent: Boolean = false
)

@Entity
data class Log(@PrimaryKey(autoGenerate = true) val id: Long = 0, val taskId: Long, val text: String, val ts: Long = System.currentTimeMillis())

@Entity
data class Pomo(@PrimaryKey(autoGenerate = true) val id: Long = 0, val ts: Long, val minutes: Int)

@Dao
interface Dao {
    @Query("SELECT * FROM Task") fun tasks(): Flow<List<Task>>
    @Query("SELECT * FROM Task") suspend fun list(): List<Task>
    @Query("SELECT * FROM Task WHERE id=:id") suspend fun get(id: Long): Task?
    @Insert suspend fun add(t: Task): Long
    @Update suspend fun update(t: Task)
    @Insert suspend fun log(l: Log)
    @Query("DELETE FROM Task WHERE id=:id") suspend fun delete(id: Long)
    @Query("UPDATE Task SET dependsOn=0 WHERE dependsOn=:id") suspend fun clearDep(id: Long)
    @Query("SELECT * FROM Log") fun allLogs(): Flow<List<Log>>
    @Insert suspend fun pomo(p: Pomo)
    @Query("SELECT * FROM Pomo") fun pomos(): Flow<List<Pomo>>
    @Query("SELECT * FROM Log ORDER BY ts DESC LIMIT 200") fun logs(): Flow<List<Log>>
}

val M12 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE Task ADD COLUMN important INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE Task ADD COLUMN urgent INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS Pomo (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ts INTEGER NOT NULL, minutes INTEGER NOT NULL)")
    }
}

@Database(entities = [Task::class, Log::class, Pomo::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): Dao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context): Db = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "plan.db").addMigrations(M12).build().also { i = it }
        }
    }
}
