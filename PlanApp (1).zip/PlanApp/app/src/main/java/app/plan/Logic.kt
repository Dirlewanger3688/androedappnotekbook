package app.plan

import android.content.Context
import androidx.compose.ui.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

object Logic {
    // запис у БД не залежить від життя екрана, тому не обривається при закритті діалогу
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun today() = LocalDate.now().toEpochDay()
    fun hm(m: Int) = "%02d:%02d".format(m / 60, m % 60)
    fun parseTime(s: String): Int = runCatching { val p = s.trim().split(":", "."); p[0].toInt() * 60 + p[1].toInt() }.getOrDefault(540)

    fun block(t: Task) = when {
        t.minutes < 0 -> "Без часу"; t.minutes < 720 -> "Ранок"; t.minutes < 1020 -> "День"; else -> "Вечір"
    }

    fun color(c: String) = when (c) {
        "Навчання" -> Color(0xFF7FA6D9); "Здоров'я" -> Color(0xFF7FC99A); "Проєкти" -> Color(0xFFD9B27F); "Побут" -> Color(0xFFB0B0B0); else -> Color.hsv(c.hashCode().mod(360).toFloat(), 0.35f, 0.85f)
    }

    fun overdue(t: Task, td: Long) = if (t.kind == "PERIOD") t.periodEnd in 1 until td else t.dueDay < td

    fun visible(t: Task, all: List<Task>, td: Long): Boolean {
        if (t.status != "PENDING" || t.dueDay > td || t.lastDone == td) return false
        if (t.dependsOn == 0L) return true
        val d = all.firstOrNull { it.id == t.dependsOn } ?: return true
        return d.lastDone == td || d.status == "DONE"
    }

    fun next(t: Task, from: Long): Long = when (t.repeat) {
        "DAILY" -> from + 1
        "INTERVAL" -> from + maxOf(1, t.repeatArg)
        "DAYS" -> (1..7).map { from + it }.firstOrNull { ((t.repeatArg shr (LocalDate.ofEpochDay(it).dayOfWeek.value - 1)) and 1) == 1 } ?: (from + 1)
        else -> from
    }

    fun lightestDay(all: List<Task>, td: Long): Long =
        (1L..7L).minByOrNull { o -> all.count { it.status == "PENDING" && it.dueDay == td + o } }!! + td

    // Чи припадає завдання на день d (з урахуванням повторень і періодів)
    fun occurs(t: Task, d: Long): Boolean {
        if (t.status != "PENDING") return false
        if (t.kind == "PERIOD") return d in t.dueDay..maxOf(t.periodEnd, t.dueDay)
        if (d < t.dueDay) return false
        return when (t.repeat) {
            "DAILY" -> true
            "INTERVAL" -> (d - t.dueDay) % maxOf(1, t.repeatArg) == 0L
            "DAYS" -> ((t.repeatArg shr (LocalDate.ofEpochDay(d).dayOfWeek.value - 1)) and 1) == 1
            else -> d == t.dueDay
        }
    }

    // ---- статистика ----
    private fun dayOf(ts: Long) = Instant.ofEpochMilli(ts).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
    fun byDay(logs: List<Log>, prefix: String): Map<Long, Int> =
        logs.filter { it.text.startsWith(prefix) }.groupingBy { dayOf(it.ts) }.eachCount()
    fun pomoByDay(p: List<Pomo>): Map<Long, Int> = p.groupBy { dayOf(it.ts) }.mapValues { e -> e.value.sumOf { it.minutes } }
    fun sum(m: Map<Long, Int>, a: Long, b: Long): Int = if (b < a) 0 else (a..b).sumOf { m[it] ?: 0 }

    fun periods(): List<Triple<String, LocalDate, LocalDate>> {
        val t = LocalDate.now(); val w = t.minusDays((t.dayOfWeek.value - 1).toLong())
        val m = t.withDayOfMonth(1); val y = t.withDayOfYear(1)
        return listOf(Triple("Тиждень", w, w.minusWeeks(1)), Triple("Місяць", m, m.minusMonths(1)), Triple("Рік", y, y.minusYears(1)))
    }

    // поточний період до сьогодні проти такого ж відрізка попереднього періоду
    fun compare(m: Map<Long, Int>, start: LocalDate, prev: LocalDate): Pair<Int, Int> {
        val td = LocalDate.now().toEpochDay(); val len = td - start.toEpochDay()
        val prevEnd = minOf(prev.toEpochDay() + len, start.toEpochDay() - 1)
        return sum(m, start.toEpochDay(), td) to sum(m, prev.toEpochDay(), prevEnd)
    }

    fun pct(cur: Int, prev: Int) =
        if (prev == 0) (if (cur == 0) "0%" else "нове") else "%+d%%".format((cur - prev) * 100 / prev)

    // лінійна регресія за 6 завершених тижнів: (прогноз наступного тижня, нахил)
    fun forecast(m: Map<Long, Int>): Pair<Double, Double>? {
        val t = LocalDate.now(); val w = t.minusDays((t.dayOfWeek.value - 1).toLong()).toEpochDay()
        val ys = (6 downTo 1).map { sum(m, w - 7L * it, w - 7L * it + 6).toDouble() }
        if (ys.count { it > 0 } < 3) return null
        val n = ys.size; val xm = (n - 1) / 2.0; val ym = ys.average()
        val b = ys.indices.sumOf { (it - xm) * (ys[it] - ym) } / ys.indices.sumOf { (it - xm) * (it - xm) }
        return maxOf(0.0, ym - b * xm + b * n) to b
    }

    // ---- імпорт ----
    suspend fun importJson(c: Context, s: String): Int {
        val a = JSONArray(s); val dao = Db.get(c).dao()
        val map = HashMap<Long, Long>(); val deps = ArrayList<Pair<Long, Long>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val t = Task(title = o.getString("title"), category = o.optString("category", "Побут"), kind = o.optString("kind", "DAY"),
                minutes = o.optInt("minutes", -1), duration = o.optInt("duration", 0), dueDay = o.optLong("dueDay", today()),
                periodEnd = o.optLong("periodEnd", 0), target = o.optInt("target", 1), done = o.optInt("done", 0),
                repeat = o.optString("repeat", "NONE"), repeatArg = o.optInt("repeatArg", 0), streak = o.optInt("streak", 0),
                lastDone = o.optLong("lastDone", -1), status = o.optString("status", "PENDING"), persistent = o.optBoolean("persistent"),
                important = o.optBoolean("important"), urgent = o.optBoolean("urgent"))
            val nid = dao.add(t)
            map[o.optLong("id")] = nid; deps.add(nid to o.optLong("dependsOn", 0))
            Notify.schedule(c, t.copy(id = nid))
        }
        deps.forEach { (nid, old) ->
            if (old != 0L) map[old]?.let { dep -> dao.get(nid)?.let { x -> dao.update(x.copy(dependsOn = dep)) } }
        }
        return a.length()
    }

    suspend fun update(c: Context, t: Task) {
        val dao = Db.get(c).dao()
        dao.update(t); dao.log(Log(taskId = t.id, text = "Змінено · ${t.title}"))
        Notify.cancel(c, t.id); Notify.schedule(c, t)
    }

    suspend fun delete(c: Context, t: Task) {
        val dao = Db.get(c).dao()
        dao.log(Log(taskId = t.id, text = "Видалено · ${t.title}"))
        Notify.cancel(c, t.id); dao.clearDep(t.id); dao.delete(t.id)
    }

    // ---- голосовий ввід: назва, тег, час, дата, тривалість, повторення, важливість ----
    private val NW = mapOf("один" to 1, "два" to 2, "дві" to 2, "три" to 3, "чотири" to 4, "пять" to 5, "шість" to 6, "сім" to 7)
    private fun nv(x: String): Int = x.toIntOrNull() ?: NW[x.replace("’", "").replace("'", "")] ?: 1
    private val NUMS = """\d+|один|два|дві|три|чотири|п[’']ять|шість|сім"""
    private val WD = listOf("понеділ", "вівтор", "серед", "четвер", "п.ятниц", "субот", "неділ").map { Regex("^$it") }
    private fun wd(x: String?): Int = WD.indexOfFirst { it.containsMatchIn(x ?: "") }
    private fun dowOf(d: Long) = LocalDate.ofEpochDay(d).dayOfWeek.value - 1
    private fun W(r: String) = Regex("(?<![\\p{L}])(?:$r)(?![\\p{L}])")

    fun parseVoice(src: String): Task {
        var s = " " + src.lowercase().replace(Regex("""(\d)\s*[:.]\s*(\d{2})(?!\d)"""), "\$1:\$2").replace(Regex("""[,!?;.]"""), " ") + " "
        var k = "DAY"; var min = -1; var dur = 0; var due = today(); var rep = "NONE"; var arg = 1
        var imp = false; var urg = false; var pers = false; var cat = "Побут"; var target = 1; var pe = 0L
        fun cut(r: String, f: (MatchResult) -> Unit) {
            val re = W(r); val m = re.find(s) ?: return
            s = re.replaceFirst(s, " "); f(m)
        }
        s = Regex("""^\s*(?:додай|створи|нагадай|запиши|треба|потрібно)\s+(?:мені\s+)?""").replaceFirst(s, " ")
        cut("""не\s+терміново|не\s+термінове|не\s+термінова""") {}
        cut("""терміново|термінове|термінова|негайно""") { urg = true }
        cut("""не\s+важливо|не\s+важливе|не\s+важлива""") {}
        cut("""(?:дуже\s+)?(?:важливо|важливе|важлива)""") { imp = true }
        cut("""наполегливо|наполегливе|наполегливий""") { pers = true }
        cut("""(?:(?:в|у)\s+)?(?:тег|тегом|категорі[яюї]|мітка|міткою)\s+(\p{L}[\p{L}’']*)""") { m ->
            val w = m.groupValues[1]
            cat = when {
                w.startsWith("побут") -> "Побут"; w.startsWith("навч") -> "Навчання"; w.startsWith("здоров") -> "Здоров'я"
                Regex("^про[єе]кт").containsMatchIn(w) -> "Проєкти"; else -> w.replaceFirstChar { it.uppercase() }
            }
        }
        // повторення
        cut("""(?:по|у|в)\s+будні\p{L}*|щобудня""") { rep = "DAYS"; arg = 31 }
        cut("""(?:по|у|в)\s+вихідн\p{L}*""") { rep = "DAYS"; arg = 96 }
        run {
            val T = s.trim().split(Regex("\\s+")); val K = mutableListOf<String>(); var mk = 0; var i = 0
            while (i < T.size) {
                val w = T[i]
                if (Regex("""^що\p{L}""").containsMatchIn(w) && wd(w.drop(2)) >= 0) { mk = mk or (1 shl wd(w.drop(2))); i++; continue }
                if (Regex("""^(по|кожн\p{L}*)$""").matches(w) && wd(T.getOrNull(i + 1)) >= 0) {
                    var j = i + 1
                    while (j < T.size) {
                        if (wd(T[j]) >= 0) { mk = mk or (1 shl wd(T[j])); j++ }
                        else if (Regex("""^(і|та|й)$""").matches(T[j]) && wd(T.getOrNull(j + 1)) >= 0) j++
                        else break
                    }
                    i = j; continue
                }
                K.add(w); i++
            }
            if (mk != 0) { rep = "DAYS"; arg = mk }
            s = " " + K.joinToString(" ") + " "
        }
        cut("""щодня|щоденно|кожного\s+дня|кожен\s+день|кожний\s+день""") { rep = "DAILY" }
        cut("""через\s+день""") { rep = "INTERVAL"; arg = 2 }
        cut("""(?:кожні|через|раз\s+на)\s+($NUMS)\s+дн\p{L}*""") { m -> rep = "INTERVAL"; arg = nv(m.groupValues[1]) }
        cut("""($NUMS)\s+раз\p{L}*\s+(?:на|за)\s+(тиждень|місяць)""") { m ->
            val n = nv(m.groupValues[1]); val mo = m.groupValues[2] == "місяць"
            if (n < 2) { rep = "INTERVAL"; arg = if (mo) 30 else 7 } else { k = "PERIOD"; target = n; pe = due + (if (mo) 30 else 7) }
        }
        cut("""щотижня|щотижнево|раз\s+на\s+тиждень|кожного\s+тижня|кожен\s+тиждень""") { rep = "INTERVAL"; arg = 7 }
        cut("""до\s+кінця\s+(місяця|тижня)""") { m ->
            val t = today(); k = "PERIOD"
            pe = if (m.groupValues[1] == "тижня") t - dowOf(t) + 6 else LocalDate.ofEpochDay(t).let { it.withDayOfMonth(it.lengthOfMonth()).toEpochDay() }
        }
        // час доби
        cut("""(?:о|об|в|у)\s*(\d{1,2})(?::(\d{2}))?(?:\s*(?:годин\p{L}*|год))?(?:\s+(ранку|вранці|зранку|дня|вдень|вечора|ввечері|вночі|ночі))?""") { m ->
            var h = m.groupValues[1].toInt(); val w = m.groupValues[3]
            if (h <= 24) {
                if (Regex("веч|дня|вдень").containsMatchIn(w) && h < 12) h += 12
                if (w.contains("ноч") && h == 12) h = 0
                min = (h % 24) * 60 + (m.groupValues[2].toIntOrNull() ?: 0)
            }
        }
        // тривалість
        val P = """(?:тривалістю\s+|на\s+|протягом\s+)?"""
        cut(P + """півтори\s+годин\p{L}*""") { dur = 90 }
        cut(P + """(?:пів\s*години|півгодини)""") { dur = 30 }
        cut(P + """годину""") { dur = 60 }
        cut(P + """($NUMS)\s*(?:годин\p{L}*|год)(?:\s+(\d+)\s*(?:хвилин\p{L}*|хв))?""") { m -> dur = nv(m.groupValues[1]) * 60 + (m.groupValues[2].toIntOrNull() ?: 0) }
        cut(P + """(\d+)\s*(?:хвилин\p{L}*|хв)""") { m -> dur = m.groupValues[1].toInt() }
        // дата
        cut("післязавтра") { due += 2 }
        cut("завтра") { due += 1 }
        cut("сьогодні") {}
        cut("""(?:в|у|на)\s+(понеділок|вівторок|середу|четвер|п[’']ятницю|суботу|неділю)""") { m ->
            val t = today(); val d = (wd(m.groupValues[1]) - dowOf(t) + 7) % 7; due = t + (if (d == 0) 7 else d)
        }
        var ti = s.replace(Regex("\\s+"), " ").trim()
        ti = ti.replace(Regex("^(?:мені|на|в|у|о|із|з)\\s+"), "").replace(Regex("(?:\\s+(?:на|в|у|о|із|з|по|до|кожні|через))+$"), "").trim()
        return Task(title = ti.replaceFirstChar { it.uppercase() }, category = cat,
            kind = if (min >= 0 && k != "PERIOD") "EXACT" else k, minutes = min, duration = dur, dueDay = due, periodEnd = pe,
            target = target, repeat = rep, repeatArg = arg, persistent = pers, important = imp, urgent = urg)
    }

    suspend fun create(c: Context, t: Task) {
        val dao = Db.get(c).dao()
        val id = dao.add(t)
        dao.log(Log(taskId = id, text = "Створено · ${t.title}"))
        Notify.schedule(c, t.copy(id = id))
    }

    suspend fun move(c: Context, t: Task, day: Long) {
        val dao = Db.get(c).dao()
        val n = t.copy(dueDay = day, periodEnd = if (t.kind == "PERIOD") maxOf(t.periodEnd, day) else 0)
        dao.update(n); dao.log(Log(taskId = t.id, text = "Перенесено · ${t.title}"))
        Notify.schedule(c, n)
    }

    suspend fun checkIn(c: Context, id: Long, action: String) {
        val dao = Db.get(c).dao()
        val t = dao.get(id) ?: return
        val td = today(); val rep = t.repeat != "NONE"
        val n = when (action) {
            "DONE" -> {
                val st = if (t.lastDone == td - 1) t.streak + 1 else if (t.lastDone == td) t.streak else 1
                val dn = t.done + 1
                if (rep) t.copy(done = 0, streak = st, lastDone = td, dueDay = next(t, td))
                else t.copy(done = dn, streak = st, lastDone = td, status = if (dn >= t.target) "DONE" else "PENDING")
            }
            "SKIP" -> if (rep) t.copy(streak = 0, dueDay = next(t, td), lastDone = td) else t.copy(status = "SKIPPED", streak = 0)
            else -> t.copy(dueDay = td + 1)
        }
        dao.update(n)
        dao.log(Log(taskId = id, text = (when (action) { "DONE" -> "Виконано"; "SKIP" -> "Пропущено"; else -> "Відкладено" }) + " · ${t.title}"))
        Notify.cancel(c, id)
        if (n.status == "PENDING") Notify.schedule(c, n)
        if (action == "DONE") dao.list().filter { it.dependsOn == id && it.status == "PENDING" && it.kind != "EXACT" }
            .forEach { Notify.at(c, it.id, System.currentTimeMillis() + 1000) }
    }

    // Дуже проста розмова: "додай купити хліб завтра о 18:30", "щодня зарядка о 7"
    suspend fun voiceAdd(c: Context, s: String) {
        val m = Regex("(?:\\bо|\\bна|\\bв)\\s*(\\d{1,2})(?:[:. ](\\d{2}))?\\b").find(s)
        var title = s.replace(Regex("^(додай|створи|нагадай)\\s*", RegexOption.IGNORE_CASE), "")
        m?.let { title = title.replace(it.value, "") }
        title = title.replace("завтра", "").replace("щодня", "").replace(Regex("\\s+"), " ").trim()
        if (title.isEmpty()) return
        val min = m?.let { it.groupValues[1].toInt() * 60 + (it.groupValues[2].toIntOrNull() ?: 0) } ?: -1
        val td = today() + if (s.contains("завтра")) 1 else 0
        create(c, Task(title = title.replaceFirstChar { it.uppercase() }, kind = if (min >= 0) "EXACT" else "DAY", minutes = min,
            dueDay = td, repeat = if (s.contains("щодня")) "DAILY" else "NONE"))
    }

    fun toJson(l: List<Task>): String = JSONArray(l.map { t ->
        JSONObject().put("id", t.id).put("title", t.title).put("category", t.category).put("kind", t.kind)
            .put("minutes", t.minutes).put("duration", t.duration).put("dueDay", t.dueDay).put("periodEnd", t.periodEnd)
            .put("target", t.target).put("done", t.done).put("repeat", t.repeat).put("repeatArg", t.repeatArg)
            .put("dependsOn", t.dependsOn).put("streak", t.streak).put("status", t.status)
            .put("lastDone", t.lastDone).put("persistent", t.persistent).put("important", t.important).put("urgent", t.urgent)
    }).toString(2)
}
