package app.plan

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDate

@Composable
fun StatCard(name: String, cur: Int, prev: Int, unit: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))) {
        Column(Modifier.padding(12.dp)) {
            Text(name, color = Color.Gray, fontSize = 12.sp)
            Text("$cur $unit", fontSize = 22.sp)
            Text("було $prev · ${Logic.pct(cur, prev)}", color = Color.LightGray, fontSize = 13.sp)
        }
    }
}

@Composable
fun Stats(logs: List<Log>, pomos: List<Pomo>) {
    val done = remember(logs) { Logic.byDay(logs, "Виконано") }
    val skipped = remember(logs) { Logic.byDay(logs, "Пропущено") }
    val pm = remember(pomos) { Logic.pomoByDay(pomos) }
    val td = LocalDate.now().toEpochDay()
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Виконані завдання: поточний період проти такого ж відрізка попереднього", color = Color.Gray, fontSize = 12.sp) }
        items(Logic.periods()) { (name, s, p) -> val (cur, prev) = Logic.compare(done, s, p); StatCard(name, cur, prev, "завд.") }
        item { Text("Pomodoro (хвилини концентрації)", color = Color.Gray, fontSize = 12.sp) }
        items(Logic.periods()) { (name, s, p) -> val (cur, prev) = Logic.compare(pm, s, p); StatCard(name, cur, prev, "хв") }
        item {
            val vals = (13 downTo 0).map { done[td - it] ?: 0 }; val mx = maxOf(1, vals.max())
            Text("Останні 14 днів (максимум $mx за день)", color = Color.Gray, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth().height(80.dp).padding(top = 6.dp), verticalAlignment = Alignment.Bottom) {
                vals.forEach { v -> Box(Modifier.weight(1f).fillMaxHeight(maxOf(0.03f, v / mx.toFloat())).padding(horizontal = 1.dp).background(Color.White)) }
            }
        }
        item {
            val d30 = Logic.sum(done, td - 29, td); val s30 = Logic.sum(skipped, td - 29, td)
            Text("Ефективність за 30 днів: " + if (d30 + s30 == 0) "—" else "${d30 * 100 / (d30 + s30)}% (виконано $d30, пропущено $s30)")
        }
        item {
            val f = Logic.forecast(done)
            Text(if (f == null) "Прогноз: потрібно щонайменше 3 тижні з виконаними завданнями"
            else "Прогноз на наступний тиждень: ${"%.0f".format(f.first)} завд. · тенденція: " +
                    (if (f.second > 0.3) "зростання" else if (f.second < -0.3) "спад" else "стабільно") +
                    " (за останні 6 тижнів)")
        }
    }
}

@Composable
fun Pomodoro(pomos: List<Pomo>) {
    val c = LocalContext.current
    var work by rememberSaveable { mutableStateOf(true) }
    var rem by rememberSaveable { mutableIntStateOf(25 * 60) }
    var going by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(going) {
        while (going && rem > 0) { delay(1000); rem-- }
        if (going && rem <= 0) {
            going = false
            if (work) Db.get(c).dao().pomo(Pomo(ts = System.currentTimeMillis(), minutes = 25))
            Notify.ping(c, if (work) "Сесія завершена. Час відпочити 5 хв" else "Перерва закінчилась")
            work = !work; rem = if (work) 25 * 60 else 5 * 60
        }
    }
    val today = Logic.pomoByDay(pomos)[LocalDate.now().toEpochDay()] ?: 0
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(if (work) "Фокус" else "Перерва", color = Color.Gray)
        Text("%02d:%02d".format(rem / 60, rem % 60), fontSize = 72.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ going = !going }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text(if (going) "Пауза" else "Старт") }
            OutlinedButton({ going = false; work = true; rem = 25 * 60 }) { Text("Скинути") }
        }
        Spacer(Modifier.height(24.dp))
        Text("Сьогодні: ${today / 25} сесій, $today хв", color = Color.Gray, textAlign = TextAlign.Center)
        Text("Таймер працює, поки додаток відкритий", color = Color(0xFF666666), fontSize = 11.sp)
    }
}
