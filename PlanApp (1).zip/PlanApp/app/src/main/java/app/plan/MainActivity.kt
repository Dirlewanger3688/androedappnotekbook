package app.plan

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.widget.Toast
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Color.Black, surface = Color.Black, primary = Color.White, onPrimary = Color.Black,
                onBackground = Color.White, onSurface = Color.White, surfaceVariant = Color(0xFF1A1A1A))) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val c = LocalContext.current; val sc = rememberCoroutineScope()
    val dao = remember { Db.get(c).dao() }
    val tasks by dao.tasks().collectAsState(emptyList())
    val logs by dao.logs().collectAsState(emptyList())
    val allLogs by dao.allLogs().collectAsState(emptyList())
    val pomos by dao.pomos().collectAsState(emptyList())
    var tab by remember { mutableIntStateOf(0) }; var dlg by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf<Task?>(null) }; var heard by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }; var menu by remember { mutableStateOf(false) }
    val cats = (listOf("Побут", "Навчання", "Здоров'я", "Проєкти") + tasks.map { it.category }).distinct()
    val shown = if (filter.isEmpty()) tasks else tasks.filter { it.category == filter }
    val onEdit: (Task) -> Unit = { draft = it; heard = ""; dlg = true }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val txt = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (txt != null) { draft = Logic.parseVoice(txt); heard = txt; dlg = true }
    }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) sc.launch(Dispatchers.IO) { c.contentResolver.openOutputStream(u)?.use { it.write(Logic.toJson(tasks).toByteArray()) } }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) sc.launch(Dispatchers.IO) {
            val msg = try {
                val txt = c.contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
                "Імпортовано завдань: ${Logic.importJson(c, txt)}"
            } catch (e: Exception) { "Помилка імпорту файлу" }
            withContext(Dispatchers.Main) { Toast.makeText(c, msg, Toast.LENGTH_LONG).show() }
        }
    }
    val tabs = listOf("Сьогодні", "Усі", "Календар", "Матриця", "Лінія", "Статистика", "Pomodoro", "Журнал")
    Scaffold(containerColor = Color.Black,
        topBar = {
            TopAppBar(title = { Text("План") },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black, titleContentColor = Color.White),
                actions = {
                    TextButton({ voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uk-UA")) }) { Text("Голос") }
                    Box {
                        TextButton({ menu = true }) { Text("⋮") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Експорт / бекап JSON") }, { menu = false; export.launch("plan.json") })
                            DropdownMenuItem({ Text("Імпорт JSON") }, { menu = false; imp.launch(arrayOf("application/json", "text/plain")) })
                        }
                    }
                })
        },
        floatingActionButton = { FloatingActionButton({ draft = null; heard = ""; dlg = true }, containerColor = Color.White, contentColor = Color.Black) { Text("+", fontSize = 24.sp) } }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.Black, edgePadding = 0.dp) {
                tabs.forEachIndexed { i, n -> Tab(tab == i, { tab = i }) { Text(n, Modifier.padding(12.dp), maxLines = 1) } }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (listOf("" to "Усі") + cats.map { it to it }).forEach { (v, l) -> FilterChip(filter == v, { filter = v }, { Text(l, fontSize = 12.sp) }) }
            }
            when (tab) {
                0 -> Today(tasks, filter, onEdit)
                1 -> AllTasks(shown, onEdit)
                2 -> CalendarScreen(shown, onEdit)
                3 -> Matrix(shown, onEdit)
                4 -> Timeline(shown, onEdit)
                5 -> Stats(allLogs, pomos)
                6 -> Pomodoro(pomos)
                else -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(logs) { l ->
                        Text("${SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(l.ts))}  ${l.text}", color = Color.LightGray, fontSize = 13.sp)
                    }
                }
            }
        }
    }
    if (dlg) AddDialog(tasks, cats, draft, heard) { dlg = false }
}

@Composable
fun Today(all: List<Task>, filter: String, onEdit: (Task) -> Unit) {
    val c = LocalContext.current; val sc = rememberCoroutineScope(); val td = Logic.today()
    val vis = all.filter { Logic.visible(it, all, td) && (filter.isEmpty() || it.category == filter) }
    val over = vis.filter { Logic.overdue(it, td) }
    val rest = vis - over.toSet()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (over.isNotEmpty()) {
            item { Text("Прострочено", color = Color.Gray) }
            item {
                Row {
                    TextButton({ sc.launch { over.forEach { Logic.move(c, it, td + 1) } } }) { Text("Усі на завтра") }
                    TextButton({ sc.launch { val d = Logic.lightestDay(all, td); over.forEach { Logic.move(c, it, d) } } }) { Text("На вільний день") }
                }
            }
            items(over) { t -> TaskRow(t, onEdit) }
        }
        listOf("Ранок", "День", "Вечір", "Без часу").forEach { b ->
            val l = rest.filter { Logic.block(it) == b }.sortedBy { it.minutes }
            if (l.isNotEmpty()) { item { Text(b, color = Color.Gray) }; items(l) { t -> TaskRow(t, onEdit) } }
        }
        if (vis.isEmpty()) item { Text("На сьогодні нічого немає", color = Color.Gray) }
    }
}

@Composable
fun TaskRow(t: Task, onEdit: (Task) -> Unit) {
    val c = LocalContext.current; val sc = rememberCoroutineScope()
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF111111))) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(Logic.color(t.category), CircleShape)); Spacer(Modifier.width(8.dp))
                Column {
                    Text(t.title, color = Color.White)
                    Text(buildString {
                        if (t.minutes >= 0) append(Logic.hm(t.minutes) + " · ")
                        if (t.duration > 0) append("${t.duration} хв · ")
                        append(t.category); if (t.streak > 1) append(" · серія ${t.streak}")
                    }, color = Color.Gray, fontSize = 12.sp)
                }
            }
            if (t.target > 1) {
                LinearProgressIndicator(progress = { t.done.toFloat() / t.target }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = Color.White, trackColor = Color(0xFF333333))
                Text("${t.done}/${t.target}", color = Color.Gray, fontSize = 12.sp)
            }
            Row {
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "DONE") } }) { Text("Виконано") }
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "SKIP") } }) { Text("Пропущено") }
                TextButton({ sc.launch { Logic.checkIn(c, t.id, "POSTPONE") } }) { Text("Відкласти") }
            }
            TaskActions(t, onEdit)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Chips(opts: List<Pair<String, String>>, sel: String, on: (String) -> Unit) =
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        opts.forEach { (v, l) -> FilterChip(sel == v, { on(v) }, { Text(l, fontSize = 12.sp) }) }
    }
