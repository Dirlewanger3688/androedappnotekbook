package app.plan

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.time.*

object Notify {
    private fun pi(c: Context, id: Long, a: String) = PendingIntent.getBroadcast(
        c, id.toInt(), Intent(c, Rcv::class.java).setAction(a).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun at(c: Context, id: Long, ms: Long) {
        val am = c.getSystemService(AlarmManager::class.java)
        val p = pi(c, id, "FIRE")
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p)
    }

    fun schedule(c: Context, t: Task) {
        if (t.kind != "EXACT" || t.minutes < 0 || t.status != "PENDING") return
        val ms = LocalDateTime.of(LocalDate.ofEpochDay(t.dueDay), LocalTime.of(t.minutes / 60, t.minutes % 60))
            .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (ms > System.currentTimeMillis()) at(c, t.id, ms)
    }

    fun ping(c: Context, text: String) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tasks", "Завдання", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(999999, NotificationCompat.Builder(c, "tasks").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Pomodoro").setContentText(text).setAutoCancel(true).build())
    }

    fun cancel(c: Context, id: Long) {
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id, "FIRE"))
        c.getSystemService(NotificationManager::class.java).cancel(id.toInt())
    }

    fun show(c: Context, t: Task) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tasks", "Завдання", NotificationManager.IMPORTANCE_HIGH))
        val n = NotificationCompat.Builder(c, "tasks").setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(t.title).setContentText(t.category).setAutoCancel(false)
            .addAction(0, "Зроблено", pi(c, t.id, "DONE"))
            .addAction(0, "Через 15 хв", pi(c, t.id, "SNOOZE"))
            .addAction(0, "Ввечері", pi(c, t.id, "EVENING")).build()
        nm.notify(t.id.toInt(), n)
    }
}

class Rcv : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0); val a = i.action ?: return
        val p = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = Db.get(c).dao(); val t = dao.get(id)
                val now = System.currentTimeMillis()
                when (a) {
                    "FIRE" -> if (t != null && Logic.visible(t, dao.list(), Logic.today())) {
                        Notify.show(c, t)
                        if (t.persistent) Notify.at(c, id, now + 10 * 60_000)   // наполегливе: повтор кожні 10 хв
                    }
                    "DONE" -> Logic.checkIn(c, id, "DONE")
                    "SNOOZE" -> { Notify.cancel(c, id); Notify.at(c, id, now + 15 * 60_000) }
                    "EVENING" -> {
                        Notify.cancel(c, id)
                        val e = LocalDate.now().atTime(19, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        Notify.at(c, id, if (e > now) e else now + 3600_000)
                    }
                }
            } finally { p.finish() }
        }
    }
}

// Відновлення нагадувань після перезавантаження телефону
class BootRcv : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        val p = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { Db.get(c).dao().list().forEach { Notify.schedule(c, it) } } finally { p.finish() }
        }
    }
}
