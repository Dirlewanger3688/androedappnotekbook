package app.plan

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val uk = Locale("uk")

// ---------------- Календар: рік / місяць / тиждень / 3 дні / день ----------------
@Composable
fun CalendarScreen(all: List<Task>, onEdit: (Task) -> Unit) {
    var mode by remember { mutableStateOf("MONTH") }
    var anchor by remember { mutableStateOf(LocalDate.now()) }
    fun shift(n: Int) {
        anchor = when (mode) {
            "YEAR" -> anchor.plusYears(n.toLong()); "MONTH" -> anchor.plusMonths(n.toLong())
            "WEEK" -> anchor.plusWeeks(n.toLong()); "3DAY" -> anchor.plusDays(3L * n); else -> anchor.plusDays(n.toLong())
        }
    }
    val title = when (mode) {
        "YEAR" -> "${anchor.year}"
        "MONTH" -> anchor.format(DateTimeFormatter.ofPattern("LLLL yyyy", uk))
        else -> anchor.format(DateTimeFormatter.ofPattern("d MMM yyyy", uk))
    }
    Column {
        Box(Modifier.padding(horizontal = 8.dp)) {
            Chips(listOf("YEAR" to "Рік", "MONTH" to "Місяць", "WEEK" to "Тиждень", "3DAY" to "3 дні", "DAY" to "День"), mode) { mode = it }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ shift(-1) }) { Text("<") }
            Text(title, Modifier.weight(1f), textAlign = TextAlign.Center)
            TextButton({ shift(1) }) { Text(">") }
        }
        when (mode) {
            "YEAR" -> YearView(all, anchor.year) { m -> anchor = LocalDate.of(anchor.year, m, 1); mode = "MONTH" }
            "MONTH" -> MonthView(all, anchor) { d -> anchor = d; mode = "DAY" }
            else -> {
                val n = when (mode) { "WEEK" -> 7; "3DAY" -> 3; else -> 1 }
                val start = if (mode == "WEEK") anchor.minusDays((anchor.dayOfWeek.value - 1).toLong()) else anchor
                DaysList((0 until n).map { start.plusDays(it.toLong()) }, all, onEdit)
            }
        }
    }
}

@Composable
fun YearView(all: List<Task>, year: Int, onMonth: (Int) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items((1..12).toList()) { m ->
            val first = LocalDate.of(year, m, 1)
            val n = (0 until first.lengthOfMonth()).sumOf { d -> all.count { Logic.occurs(it, first.plusDays(d.toLong()).toEpochDay()) } }
            Row(Modifier.fillMaxWidth().background(Color(0xFF111111), RoundedCornerShape(8.dp)).clickable { onMonth(m) }.padding(14.dp)) {
                Text(first.format(DateTimeFormatter.ofPattern("LLLL", uk)), Modifier.weight(1f))
                Text("$n", color = Color.Gray)
            }
        }
    }
}

@Composable
fun MonthView(all: List<Task>, a: LocalDate, onDay: (LocalDate) -> Unit) {
    val first = a.withDayOfMonth(1); val off = first.dayOfWeek.value - 1; val len = a.lengthOfMonth(); val today = LocalDate.now()
    Column(Modifier.padding(8.dp)) {
        Row { listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Нд").forEach { Text(it, Modifier.weight(1f), color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp) } }
        for (r in 0 until (off + len + 6) / 7) {
            Row {
                for (cl in 0 until 7) {
                    val dn = r * 7 + cl - off + 1
                    if (dn < 1 || dn > len) Spacer(Modifier.weight(1f).height(54.dp))
                    else {
                        val d = first.plusDays((dn - 1).toLong()); val n = all.count { Logic.occurs(it, d.toEpochDay()) }
                        Column(Modifier.weight(1f).height(54.dp).padding(2.dp)
                            .then(if (d == today) Modifier.border(1.dp, Color.White, RoundedCornerShape(6.dp)) else Modifier)
                            .clickable { onDay(d) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$dn", fontSize = 14.sp)
                            if (n > 0) Text("● $n", color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DaysList(days: List<LocalDate>, all: List<Task>, onEdit: (Task) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        days.forEach { d ->
            item { Text(d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", uk)), fontWeight = FontWeight.Bold) }
            val l = all.filter { Logic.occurs(it, d.toEpochDay()) }.sortedBy { it.minutes }
            if (l.isEmpty()) item { Text("—", color = Color.Gray) }
            else items(l) { t ->
                Row(Modifier.clickable { onEdit(t) }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(Logic.color(t.category), CircleShape)); Spacer(Modifier.width(8.dp))
                    Text(buildString {
                        if (t.minutes >= 0) {
                            append(Logic.hm(t.minutes))
                            if (t.duration > 0) append("–" + Logic.hm((t.minutes + t.duration) % 1440))
                            append("  ")
                        }
                        append(t.title)
                    }, fontSize = 14.sp)
                }
            }
        }
    }
}

// ---------------- Матриця Ейзенхауера ----------------
@Composable
fun Quad(name: String, sub: String, l: List<Task>, m: Modifier, pick: (Task) -> Unit) {
    Column(m.background(Color(0xFF111111), RoundedCornerShape(10.dp)).padding(10.dp).verticalScroll(rememberScrollState())) {
        Text(name, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(sub, color = Color.Gray, fontSize = 11.sp)
        l.forEach { t -> Text("• ${t.title}", Modifier.clickable { pick(t) }.padding(vertical = 4.dp), fontSize = 13.sp) }
    }
}

@Composable
fun Matrix(all: List<Task>, onEdit: (Task) -> Unit) {
    val p = all.filter { it.status == "PENDING" }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quad("Зробити", "важливе · термінове", p.filter { it.important && it.urgent }, Modifier.weight(1f).fillMaxHeight(), onEdit)
            Quad("Запланувати", "важливе · не термінове", p.filter { it.important && !it.urgent }, Modifier.weight(1f).fillMaxHeight(), onEdit)
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Quad("Делегувати", "не важливе · термінове", p.filter { !it.important && it.urgent }, Modifier.weight(1f).fillMaxHeight(), onEdit)
            Quad("Відкинути", "не важливе · не термінове", p.filter { !it.important && !it.urgent }, Modifier.weight(1f).fillMaxHeight(), onEdit)
        }
        Text("Торкніться завдання, щоб змінити його (там же перемикачі «Важливе» і «Термінове»)", color = Color.Gray, fontSize = 11.sp)
    }
}

// ---------------- Часова лінія ----------------
@Composable
fun Timeline(all: List<Task>, onEdit: (Task) -> Unit) {
    val td = LocalDate.now().toEpochDay(); val from = td - 1; val n = 21; val cell = 30.dp
    val rows = all.filter { it.status == "PENDING" }.sortedWith(compareBy({ it.category }, { it.dueDay }))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()).padding(12.dp)) {
        Row {
            Spacer(Modifier.width(120.dp))
            for (i in 0 until n) Text("${LocalDate.ofEpochDay(from + i).dayOfMonth}", Modifier.width(cell),
                color = if (from + i == td) Color.White else Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
        }
        rows.forEach { t ->
            Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text((if (t.dependsOn != 0L) "↳ " else "") + t.title, Modifier.width(120.dp).clickable { onEdit(t) }, maxLines = 1, fontSize = 12.sp, overflow = TextOverflow.Ellipsis)
                for (i in 0 until n) Box(Modifier.size(cell, 22.dp).padding(horizontal = 1.dp)
                    .background(if (Logic.occurs(t, from + i)) Logic.color(t.category) else Color(0xFF151515)))
            }
        }
        if (rows.isEmpty()) Text("Немає активних завдань", color = Color.Gray)
    }
}
